# Back Cover Brief (Excerpt)

Typography:
- Title: 12–14 pt, bold, match front cover font
- Author: 9–10 pt, regular
- Color: Navy on white OR white on navy (match front)
- Alignment: Centered, single line

Color Specifications:
- Primary (headlines): Navy Blue (match front cover exactly)
- Body text: Dark charcoal (#333) or navy
- Bullets/accents: Navy Blue
- Background: White or very light gray
- QR code: Black on white background

Files needed from author:
- Author headshot (300 dpi minimum, professional)
- BeTeachable logo file (vector: .ai, .eps, .svg)
- Final ISBN number
- Price confirmation (USD $24.99)
- Confirm paper stock (white vs cream) for spine calculation

Deliverables:
1. Back cover design proof (PDF, 300 dpi)
2. Full wrap proof (front + spine + back, with trim/bleed marks)
3. Print-ready file (PDF/X-1a:2001, CMYK, fonts embedded/outlined)
