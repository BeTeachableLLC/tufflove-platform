# TUFF LOVE — Publishing Handoff (Package Scaffold)

This package is structured for a clean handoff to a publishing/design team.  
It contains the cover reference image and the production specifications / checklist extracted from the latest build notes.

## What the publishing team should receive (recommended final deliverables)
1. **Manuscript source (editable):** `TUFF_LOVE_COMPLETE_MASTER.docx` (Word, styled)
2. **Reference PDF (for review):** `TUFF_LOVE_COMPLETE_MASTER.pdf`
3. **Original source file:** `TUFF_LOVE_COMPLETE_MASTER.md` (version-controlled)
4. **Cover files:** print-ready wrap (front/spine/back) + separate front cover
5. **Metadata:** ISBN(s), pricing, imprint, BISAC categories, author bio, etc.

## Print specifications (target)
- Trim: 6 × 9 in  
- Pages: 272 (17 signatures × 16)  
- Margins: Inside 0.9 in; Outside 0.7 in; Top 0.7 in; Bottom 0.9 in  

## Back cover needs (author-supplied items)
- Author headshot (300 dpi minimum, professional)
- BeTeachable logo file (vector: .ai, .eps, .svg)
- Final ISBN number
- Price confirmation (USD $24.99)
- Confirm paper stock (white vs cream) for spine calculation

## Pre-flight checklist (high-level)
- Colors matched (brand navy), converted once to CMYK, consistent profile
- Fonts embedded/outlined, images ≥300 DPI
- Bleed 0.125 in all sides; safe zone 0.5 in from trim for live text
- QR code scans correctly; barcode box clear zone maintained
- URLs and ™ symbols verified

## Next action required to generate the “full book” files here
The full manuscript files (`TUFF_LOVE_COMPLETE_MASTER.md` / `TUFF_LOVE_PRODUCTION_MASTER.md`) are not currently available in the runtime filesystem for conversion into DOCX/PDF.
To generate the full download package in this chat, please **re-upload the manuscript file(s)** as attachments (preferably the COMPLETE_MASTER).
