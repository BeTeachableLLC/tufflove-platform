# Publisher Specs (Excerpt)

Trim: 6 × 9 in  
Page count: 272 (17 signatures × 16)  
Margins: Inside 0.9 in; Outside 0.7 in; Top 0.7 in; Bottom 0.9 in
