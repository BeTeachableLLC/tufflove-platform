# TUFF LOVE — Publishing Handoff Package (Full Manuscript)

**Author:** Moe Mathews (BeTeachable)  
**Build date (source notes):** December 26, 2025  
**Target trim:** 6 × 9 in  
**Target page count:** 272 pages (signatures: 17 × 16)

## What’s inside this package
- `TUFF_LOVE_COMPLETE_MASTER.md` — Source master (authoritative text)
- `TUFF_LOVE_COMPLETE_MASTER_EDITABLE.docx` — Clean, editable Word build (styles applied for import)
- `TUFF_LOVE_COMPLETE_MASTER_EDITABLE.pdf` — Reference proof exported from the DOCX
- `TUFF_LOVE_PRODUCTION_MASTER.md` — Production notes/specs reference
- `TUFF_LOVE_FINAL_QUALITY_REPORT_2026.md` — Quality checks / finishing notes
- `TUFF_LOVE_Back_Cover_VA_Brief_FINAL.md` — Back cover brief + specs
- `TUFF_LOVE_Front_Cover_Reference (1).png` — Front cover reference image
- `MANIFEST_SHA256.tsv` — File sizes + SHA256 checksums for integrity verification

## Layout specifications (target)
- Trim: 6 × 9 in  
- Margins: Inside 0.9 in; Outside 0.7 in; Top 0.7 in; Bottom 0.9 in  
- Page count target: 272

## Notes for the publishing/design team
1. **Source-of-truth:** Use the `...COMPLETE_MASTER.md` file as the authoritative text.  
2. **DOCX intent:** The DOCX is provided as an editable import file (heading hierarchy, lists, and tables mapped).  
3. **PDF intent:** The PDF is a reference proof for review; it is **not** a final print-ready file (PDF/X, CMYK, bleeds, barcode, etc.).  
4. **Cover:** The included cover is a **front-cover reference**. A final print wrap (front/spine/back with bleed and barcode) should be produced per platform requirements.

## Recommended next steps
- Import manuscript into InDesign/Affinity Publisher
- Apply style sheets (body/head fonts, spacing, widows/orphans rules)
- Confirm ISBNs and finalize metadata (BISAC, price, imprint details)
- Produce final cover wrap (exact spine width based on chosen paper stock)
- Export print-ready PDF (PDF/X-1a or platform standard) + EPUB3 (if applicable)

## Integrity verification
Use `MANIFEST_SHA256.tsv` to confirm the files received match the source package.
